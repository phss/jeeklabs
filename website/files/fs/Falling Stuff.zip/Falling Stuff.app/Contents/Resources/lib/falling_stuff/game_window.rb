#!/usr/bin/env ruby -wKU
# 
#  game_window.rb
#  falling_stuff
#  
#  Created by Paulo Schneider on 2007-12-25.
#  Copyright 2007 Jeek Labs. All rights reserved.
# 

class GameWindow < Gosu::Window
  
  attr_reader :resources, :states
  
  def initialize
    super(340, 440, false)
    self.caption = "Falling Stuff"
    
    load_resources
    
    @states = Hash.new
    @states[:start] = StartState.new(self)
    @states[:play]  = PlayState.new(self)
    @states[:pause] = PauseState.new(self)
    @states[:end]   = EndState.new(self)
    @current_state  = @states[:start]
  end
  
  def update
    @current_state.update
  end
  
  def draw
    @current_state.draw
  end
  
  def button_down(id)
    @current_state.button_down(id)
  end
  
  def button_up(id)
    @current_state.button_up(id) if @current_state.respond_to? "button_up"
  end
  
  def change_state(state)
    @current_state = @states[state]
    @current_state.on_enter
  end

  private
  
  def load_resources
    # Images
    @resources = Hash.new
    @resources["splash"] = Gosu::Image.new(self, "resources/images/splash.png", false)
    @resources["border"] = Gosu::Image.new(self, "resources/images/moldura.png", false)
    @resources["score"]  = Gosu::Image.new(self, "resources/images/score.png", false)
    @resources["next"]   = Gosu::Image.new(self, "resources/images/next.png", false)
    @resources["esc2pause"]  = Gosu::Image.new(self, "resources/images/esc2pause.png", false)
    @resources["copyrite"]   = Gosu::Image.new(self, "resources/images/copyrite.png", false)
    @resources["paused"]     = Gosu::Image.new(self, "resources/images/pause.png", false)
    @resources["gameovered"] = Gosu::Image.new(self, "resources/images/gameover.png", false)
    
    @resources["gray"]   = Gosu::Image.new(self, "resources/images/tetris-cinza.png", false)
    @resources["yellow"] = Gosu::Image.new(self, "resources/images/tetris-amarelo.png", false)
    @resources["blue"]   = Gosu::Image.new(self, "resources/images/tetris-azul.png", false)
    @resources["pink"]   = Gosu::Image.new(self, "resources/images/tetris-rosa.png", false)
    @resources["green"]  = Gosu::Image.new(self, "resources/images/tetris-verde.png", false)
    @resources["red"]    = Gosu::Image.new(self, "resources/images/tetris-vermelho.png", false)
    @resources["dgreen"] = Gosu::Image.new(self, "resources/images/tetris-azulescuro.png", false)
    
    # Sounds
    @resources["startup"]  = Gosu::Sample.new(self, "resources/sounds/splash.wav")
    @resources["settle"]   = Gosu::Sample.new(self, "resources/sounds/chao.wav")
    @resources["gameover"] = Gosu::Sample.new(self, "resources/sounds/gameover.wav")
    @resources["break"]    = Gosu::Sample.new(self, "resources/sounds/linha.wav")
    @resources["pause"]    = Gosu::Sample.new(self, "resources/sounds/pausa.wav")
    @resources["start"]    = Gosu::Sample.new(self, "resources/sounds/start.wav")
  end

end

#
#
#
class StartState
  
  def initialize(game_window)
    @game_window = game_window
    @font = Gosu::Font.new(@game_window, Gosu::default_font_name, 20)
    @start_timestamp = Gosu.milliseconds
    @played_startup_sound = false
  end
  
  def on_enter
    
  end
  
  def update
    if !@played_startup_sound && Gosu.milliseconds - @start_timestamp > 500
      @game_window.resources["startup"].play
      @played_startup_sound = true
    end
  end
  
  def draw
    @game_window.states[:play].draw
    @game_window.resources["splash"].draw(BLOCK_SIZE, BLOCK_SIZE, 0)
  end
  
  def button_down(id)
    case id
    when Gosu::Button::KbReturn
      @game_window.resources["start"].play
      @game_window.change_state(:play)
    end
  end
  
end

#
#
#
class PlayState
  
  def initialize(game_window)
    @game_window = game_window
    startup
  end
  
  def startup
    initialize_controls
    @shapes = [IShape, OShape, SShape, ZShape, LShape, JShape, TShape]

    @board = Board.new(@game_window)
    
    @score = 0
    @score_table = [0, 40, 100, 300, 1200]
    @level = 0
    @next_shape = @shapes[rand(@shapes.size)].new(@game_window, 0, 0)
    new_shape
    @timer = Gosu.milliseconds
    @control_timer = nil
    
    @fall_speed = 450
    @speed_counter = 0

    @font = Gosu::Font.new(@game_window, "resources/fonts/prstart.ttf", 12)
  end
  
  def on_enter
    
  end
  
  def update
    # Go down a space
    if (Gosu.milliseconds - @timer) > @fall_speed
      @shape.move_down
      if @board.collides?(@shape) 
        @game_window.resources["settle"].play
        @shape.move_up
        @board.settle_shape(@shape)
        add_to_score(@board.break_rows)
        new_shape
        
        # Check gameover
        @game_window.change_state(:end) if @board.collides?(@shape)
      end      
      @timer = Gosu.milliseconds
    end
    
    # Perform key presses
    if @game_window.button_down?(Gosu::Button::KbDown)
      @shape.move_down
      @shape.move_up if @board.collides?(@shape)
    end
    
    # HACK CODE BELOW!
    return if (@control_timer == nil || Gosu.milliseconds - @control_timer[1] < 600)
    @shape.send(@action[@control_timer[0]]) while !@board.collides?(@shape)
    @shape.send(@undo[@control_timer[0]])
    @control_timer = nil
  end
  
  def button_down(id)
    @control_timer = nil
    case id
    when Gosu::Button::KbSpace
      @shape.move_down while !@board.collides?(@shape)
      @shape.move_up
    when Gosu::Button::KbEscape
      @game_window.change_state(:pause)
    end
    
    if @action.has_key? id
      @control_timer = [id, Gosu.milliseconds] if id == Gosu::Button::KbLeft || id == Gosu::Button::KbRight
      @shape.send(@action[id]) 
      @shape.send(@undo[id]) if @board.collides?(@shape)
    end    
  end
  
  def button_up(id)
    @control_timer = nil
  end
  
  def draw
    @board.draw
    @shape.draw(BOARD_START_X, BOARD_START_Y)
    @game_window.resources["score"].draw(265, 35, 0)
    @font.draw(@score, 330 - @font.text_width(@score), 55, 0)
    @game_window.resources["next"].draw(270, 130, 0)
    @next_shape.draw(NEXT_SHAPE_X, NEXT_SHAPE_Y)
    @game_window.resources["esc2pause"].draw(245, 350, 0)
    @game_window.resources["copyrite"].draw(245, 400, 0)
  end
  
  def add_to_score(lines)
    @score = @score + (@score_table[lines] * (@level + 1))
    @speed_counter = @speed_counter + lines
    
    # Increase speed
    if @speed_counter >= 4
      @fall_speed = @fall_speed - 30
      @speed_counter = 4 - @speed_counter
      @level = @level + 1
    end
    
    @game_window.resources["break"].play if lines > 0
  end
  
  def new_shape
    @shape = @next_shape #.class.new(self, (@board.width/2)-1, 0)
    @shape.position((@board.width/2)-1, 0)
    
    @next_shape = @shapes[rand*@shapes.size].new(@game_window, 0, 0)
  end
  
  def initialize_controls
    @action = Hash.new
    @undo = Hash.new
    @action[Gosu::Button::KbLeft]  = "move_left"
    @undo[Gosu::Button::KbLeft]    = "move_right"
    @action[Gosu::Button::KbRight] = "move_right"
    @undo[Gosu::Button::KbRight]   = "move_left"
    # @action[Gosu::Button::KbDown]  = "move_down"
    # @undo[Gosu::Button::KbDown]    = "move_up"
    @action[Gosu::Button::KbUp]    = "rotate_counter_clockwise"
    @undo[Gosu::Button::KbUp]      = "rotate_clockwise"    
  end
  
end

#
#
#
class PauseState
  
  def initialize(game_window)
    @game_window = game_window
  end
  
  def on_enter
    @game_window.resources["pause"].play
  end

  def update

  end

  def draw
    @game_window.states[:play].draw
    @game_window.resources["paused"].draw(30, 150, 0)
  end

  def button_down(id)
    case id
    when Gosu::Button::KbEscape
      @game_window.change_state(:play)
    when @game_window.char_to_button_id('q')
      @game_window.close
    when @game_window.char_to_button_id('r')
      @game_window.states[:play].startup
      @game_window.change_state(:play)
    end
  end
end

#
#
#
class EndState
  
  def initialize(game_window)
    @game_window = game_window
  end
  
  def on_enter
    @game_window.resources["gameover"].play
  end

  def update

  end

  def draw
    @game_window.states[:play].draw
    @game_window.resources["gameovered"].draw(40, 180, 0)
  end

  def button_down(id)
    case id
    when Gosu::Button::KbReturn
      @game_window.states[:play].startup
      @game_window.change_state(:play)
    end
  end
end