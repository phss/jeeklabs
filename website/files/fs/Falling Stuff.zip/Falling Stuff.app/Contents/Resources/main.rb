#!/usr/bin/env ruby -wKU
# 
#  gosu_fs.rb
#  falling_stuff
#  
#  Created by Paulo Schneider on 2007-12-25.
#  Copyright 2007 Jeek Labs. All rights reserved.
# 

require "lib/falling_stuff"

if __FILE__ == $0
  game_window = GameWindow.new
  game_window.show
end