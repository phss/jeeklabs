# 
#  text_painter.rb
#  binary_nights
#  
#  Created by Paulo Schneider on 2008-05-28.
#  Copyright 2008 Jeek Labs. All rights reserved.
# 

require "text_painter/text_builder"
require "text_painter/mixed_text_builder"